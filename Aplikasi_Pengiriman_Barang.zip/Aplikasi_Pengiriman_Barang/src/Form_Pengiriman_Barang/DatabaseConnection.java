package Form_Pengiriman_Barang;
import java.sql.Connection;
import java.sql.DriverManager;
public class DatabaseConnection {
    private Connection connection = null;
    public Connection setConnection() {
        try{
            String url = "jdbc:mysql://localhost:3306/db_pengiriman_barang";
            String user = "root";
            String pass = "";
            String db = "db_pengiriman_barang";
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(url, user, pass);
        }catch(Exception e){
            System.out.println("Error "+e.getMessage());
        }return connection;
        }
}
