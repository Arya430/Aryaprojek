package Form_Pengiriman_Barang;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



/**
 *
 * @author OIK
 */
public class LoginKoneksi {
    public static Connection myconnection () throws ClassNotFoundException, SQLException{
        try {
        Class.forName("com.mysql.jdbc.Driver");
        Connection loginkoneksi = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/db_pengiriman_barang","root","");
        return loginkoneksi;
    
    } catch (Exception e) {
        return null;
    }
    }
    
}
