package ppl.com.absensy.base;

public interface BaseView {
    void showToast(String message);
}
