package ppl.com.absensy.base;

public interface BasePresenter {
    void onDestroy();
}
