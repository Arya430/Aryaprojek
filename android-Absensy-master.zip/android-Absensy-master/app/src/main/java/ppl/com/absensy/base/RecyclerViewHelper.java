package ppl.com.absensy.base;

import java.util.List;

public interface RecyclerViewHelper<T> {
    void updateData(List<T> data);
}
